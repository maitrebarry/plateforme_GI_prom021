<?php

class Bourses extends Controller {

    public function index() {
        $bourseModel = new Bourse();
        $bourses = $bourseModel->getAll();

        $this->view( 'bourses', [ 'bourses' => $bourses ] );
    }

}