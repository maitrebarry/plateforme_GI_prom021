<?php

class Universites extends Controller {

    public function details( $idUniversite ) {
        $universiteModel = new Universite();

        if ( isset(  $idUniversite )  && !empty( $idUniversite ) ) {
        
            $isUiniversite = $universiteModel->getById( $idUniversite );
            if ( isset( $isUiniversite ) && empty( $isUiniversite ) ) {
                exit();
            }
        } else {
            exit();
        }
      
        $universite = $universiteModel->getComplete( $idUniversite );
        $universite = $universite[0];
   
        $this->view( 'details-universite', [ 'universite' => $universite ] );
    }

}