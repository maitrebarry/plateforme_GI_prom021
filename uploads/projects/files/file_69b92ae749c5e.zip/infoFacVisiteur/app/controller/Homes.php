<?php

class Homes extends Controller {

    public function index() {
        $homeModel = new Home();
        $universiteModel = new Universite();

        $universites = $universiteModel->getAll();
        $this->view( 'home', [ 'universites' => $universites ] );

    }

}