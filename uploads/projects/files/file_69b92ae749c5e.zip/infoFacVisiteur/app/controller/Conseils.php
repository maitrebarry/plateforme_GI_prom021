<?php

class Conseils extends Controller {

    public function index() {
        $this->view( 'conseils' );
    }

}