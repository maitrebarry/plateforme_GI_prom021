<?php

class Universite extends Model
 {

    protected $table = 'universites';

    /* ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ==
    RECUPERER TOUTES LES UNIVERSITES
    ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  == */

    public function getAll()
 {

        $sql = "SELECT *
                FROM universites
                ORDER BY nom_universite ASC";

        return $this->select_data_table_join_where( $sql );

    }

    /* ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ==
    RECUPERER PAR ID
    ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  == */

    public function getById( $id )
 {

        $sql = "SELECT *
                FROM universites
                WHERE id_universite = ?";

        return $this->FetchSelectWhere(
            '*',
            'universites',
            'id_universite = ?',
            [ $id ]
        );

    }

    /* ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ==
    RECUPERER UNIVERSITES PAR TYPE
    ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  == */

    public function getByType( $type )
 {

        $sql = "SELECT *
                FROM universites
                WHERE type_universite = ?
                ORDER BY nom_universite ASC";

        return $this->FetchSelectWhere2(
            '*',
            'universites',
            'type_universite = ?',
            [ $type ]
        );

    }

    /* ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ==
    RECUPERER AVEC FILIERES
    ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  == */

    public function getWithFilieres( $id )
 {

        $sql = "
            SELECT 
                u.*,
                f.id_filiere,
                f.nom_filiere,
                f.description_filiere,
                f.niveau_filiere
            FROM universites u

            LEFT JOIN filieres f
            ON f.id_universite = u.id_universite

            WHERE u.id_universite = ?
        ";

        return $this->select_data_table_join_where(
            $sql,
            [ $id ]
        );

    }

    /* ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ==
    RECUPERER UNIVERSITES + FILIERES + DEBOUCHES
    ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  == */

    public function getComplete( $id )
 {

        $sql = "
            SELECT 
                u.id_universite,
                u.nom_universite,
                u.description_universite,
                u.logo_universite,
                u.type_universite,

                f.id_filiere,
                f.nom_filiere,
                f.description_filiere,

                d.id_debouche,
                d.nom_debouche

            FROM universites u

            LEFT JOIN filieres f
                ON f.id_universite = u.id_universite

            LEFT JOIN debouches d
                ON d.id_filiere = f.id_filiere

            WHERE u.id_universite = ?
        ";

        return $this->select_data_table_join_where(
            $sql,
            [ $id ]
        );

    }

    /* ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ==
    COUNT
    ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  == */

    public function count()
 {

        return $this->selectCount(
            'universites',
            '*'
        );

    }

}