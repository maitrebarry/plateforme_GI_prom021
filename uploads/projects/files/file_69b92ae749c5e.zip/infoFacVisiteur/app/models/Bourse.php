<?php

class Bourse extends Model
{

    protected $table = "bourses";


    /* =========================
       Récupérer toutes les bourses
    ========================= */
    public function getAll()
    {
        return $this->SelectAllData("*", $this->table);
    }


    /* =========================
       Récupérer toutes les bourses actives
    ========================= */
    public function getActives()
    {
        return $this->FetchSelectWhere2(
            "*",
            $this->table,
            "statut = ?",
            ["actif"]
        );
    }


    /* =========================
       Récupérer une bourse par ID
    ========================= */
    public function getById($id)
    {
        return $this->FetchSelectWhere(
            "*",
            $this->table,
            "id_bourse = ?",
            [$id]
        );
    }


    /* =========================
       Récupérer la dernière bourse active
    ========================= */
    public function getDerniereBourse()
    {
        $bdd = $this->bdd();

        $query = $bdd->prepare("
            SELECT *
            FROM bourses
            WHERE statut = 'actif'
            ORDER BY date_fin ASC
            LIMIT 1
        ");

        $query->execute();

        return $query->fetch(PDO::FETCH_OBJ);
    }


    /* =========================
       Ajouter une bourse
    ========================= */
    public function create($data)
    {

        $sql = "
            INSERT INTO bourses
            (nom_bourse, organisme_bourse, description_bourse, date_fin, niveau, fichier_bourse)
            VALUES (?,?,?,?,?,?)
        ";

        return $this->insertion_update_simples($sql, [
            $data['nom_bourse'],
            $data['organisme_bourse'],
            $data['description_bourse'],
            $data['date_fin'],
            $data['niveau'],
            $data['fichier_bourse']
        ]);
    }


    /* =========================
       Modifier une bourse
    ========================= */
    public function update($id, $data)
    {

        $sql = "
            UPDATE bourses
            SET
                nom_bourse = ?,
                organisme_bourse = ?,
                description_bourse = ?,
                date_fin = ?,
                niveau = ?,
                fichier_bourse = ?
            WHERE id_bourse = ?
        ";

        return $this->insertion_update_simples($sql, [
            $data['nom_bourse'],
            $data['organisme_bourse'],
            $data['description_bourse'],
            $data['date_fin'],
            $data['niveau'],
            $data['fichier_bourse'],
            $id
        ]);
    }


    /* =========================
       Supprimer une bourse
    ========================= */
    public function delete($id)
    {
        $sql = "DELETE FROM bourses WHERE id_bourse = ?";

        return $this->insertion_update_simples($sql, [$id]);
    }


    /* =========================
       Vérifier si une bourse existe déjà
    ========================= */
    public function existe($nom)
    {
        return $this->existe_deja("nom_bourse", $nom, $this->table);
    }


    /* =========================
       Récupérer les bourses par niveau
    ========================= */
    public function getByNiveau($niveau)
    {
        return $this->FetchSelectWhere2(
            "*",
            $this->table,
            "niveau = ? AND statut = 'actif'",
            [$niveau]
        );
    }

}