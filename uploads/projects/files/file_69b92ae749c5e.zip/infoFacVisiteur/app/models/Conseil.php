<?php

class Conseil  extends Model
 {

}