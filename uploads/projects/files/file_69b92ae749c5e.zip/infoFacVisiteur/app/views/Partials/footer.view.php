<!--====== Javascripts & Jquery ======-->
<script src="<?= ROOT ?>/assets/js/jquery-3.2.1.min.js"></script>
<script src="<?= ROOT ?>/assets/js/owl.carousel.min.js"></script>
<script src="<?= ROOT ?>/assets/js/jquery.countdown.js"></script>
<script src="<?= ROOT ?>/assets/js/masonry.pkgd.min.js"></script>
<script src="<?= ROOT ?>/assets/js/magnific-popup.min.js"></script>
<script src="<?= ROOT ?>/assets/js/main.js"></script>