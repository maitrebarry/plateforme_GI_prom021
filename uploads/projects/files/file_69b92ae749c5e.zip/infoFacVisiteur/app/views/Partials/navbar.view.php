    <!-- Header section  -->
    <nav class="nav-section">
        <div class="container">
            <div class="nav-right">
                <a href=""><i class="fa fa-search"></i></a>
                <a href=""><i class="fa fa-shopping-cart"></i></a>
            </div>
            <ul class="main-menu">
                <li class="active"><a href="<?= ROOT ?>/Homes">Acceuil</a></li>
                <li><a href="<?= ROOT ?>/Bourses">Bourses</a></li>
                <li><a href="<?= ROOT ?>/course.html">COURSES</a></li>
                <li><a href="<?= ROOT ?>/blog.html">blog</a></li>
                <li><a href="<?= ROOT ?>/contact.html">Contact</a></li>
            </ul>
        </div>
    </nav>
    <!-- Header section end -->