<!doctype html>
<html lang='fr'>

<?php $this->view('Partials/header') ?>

<style>
/* ================= GLOBAL ================= */

:root {
    --primary: #02023d;
    --accent: #ffd166;
    --bg: #f4f7fb;
    --card: #ffffff;
    --text: #1a1a1a;
    --muted: #6b7280;
}

body {
    background: var(--bg);
}


/* ================= PAGE ================= */

.if-page {
    padding: 20px;
    max-width: 900px;
    margin: auto;
}


/* ================= BACK BUTTON ================= */

.if-back {

    display: inline-flex;
    align-items: center;
    gap: 6px;

    padding: 8px 14px;

    background: white;

    border-radius: 8px;

    text-decoration: none;

    font-weight: 600;

    color: var(--primary);

    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);

    transition: 0.2s;
}

.if-back:hover {
    transform: translateY(-1px);
}


/* ================= UNIVERSITY HEADER PREMIUM ================= */


/* SECTION */

.if-uni-header-premium {

    margin-bottom: 30px;

}


/* COVER IMAGE */

.if-cover {

    position: relative;

    width: 100%;

    height: 180px;

    overflow: hidden;

}

.if-cover-img {

    width: 100%;

    height: 100%;

    object-fit: cover;

}


/* OVERLAY */

.if-cover-overlay {

    position: absolute;

    inset: 0;

    background: linear-gradient(to bottom,
            rgba(0, 0, 0, 0.1),
            rgba(0, 0, 0, 0.4));

}


/* CARD */

.if-uni-card {

    position: relative;

    background: var(--card);

    margin: -40px auto 0 auto;

    padding: 20px;

    border-radius: 14px;

    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);

    max-width: 900px;

    display: flex;

    align-items: center;

    gap: 20px;

}


/* LOGO WRAPPER */

.if-logo-wrapper {

    background: white;

    padding: 10px;

    border-radius: 14px;

    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);

}


/* LOGO */

.if-logo-premium {

    width: 80px;

    height: 80px;

    object-fit: contain;

}


/* INFO */

.if-uni-info {

    display: flex;

    flex-direction: column;

}


/* NAME */

.if-uni-name {

    margin: 0;

    font-size: 26px;

    font-weight: 700;

    color: var(--primary);

}


/* BADGE */

.if-uni-badge {

    margin-top: 8px;

    padding: 5px 14px;

    border-radius: 20px;

    font-size: 13px;

    font-weight: 600;

    width: fit-content;

}

.public {

    background: #e3f2fd;

    color: #1976d2;

}

.prive {

    background: #fff3e0;

    color: #ffd166;

}


/* ================= MOBILE ================= */

@media(max-width:768px) {

    .if-cover {

        height: 140px;

    }

    .if-uni-card {

        flex-direction: column;

        text-align: center;

        margin-top: -50px;

        padding: 16px;

    }

    .if-logo-premium {

        width: 90px;

        height: 90px;

    }

    .if-uni-name {

        font-size: 20px;

    }

}


/* ================= DROPDOWN ================= */

.if-dropdown {

    margin-top: 14px;

    background: var(--card);

    border-radius: 12px;

    box-shadow: 0 4px 18px rgba(0, 0, 0, 0.05);

    overflow: hidden;

}

.if-dropdown-btn {

    width: 100%;

    padding: 16px;

    background: none;

    border: none;

    font-size: 16px;

    font-weight: 600;

    color: var(--text);

    cursor: pointer;

    display: flex;

    align-items: center;

    gap: 8px;

}

.if-dropdown-btn:hover {
    background: #f9fafc;
}

.if-dropdown-content {

    display: none;

    padding: 16px;

    border-top: 1px solid #eee;

}


/* ================= SUB DROPDOWN ================= */

.if-sub-dropdown {

    margin-top: 10px;

}

.if-sub-btn {

    width: 100%;

    padding: 12px;

    background: #f9fafc;

    border: none;

    border-radius: 8px;

    font-size: 15px;

    font-weight: 600;

    cursor: pointer;

    display: flex;

    align-items: center;

    gap: 6px;

}

.if-sub-content {

    display: none;

    padding: 10px;

}


/* ================= INNER DROPDOWN ================= */

.if-inner-dropdown {

    margin-top: 8px;

}

.if-inner-btn {

    width: 100%;

    padding: 10px;

    background: #f4f7fb;

    border: none;

    border-radius: 8px;

    font-size: 14px;

    cursor: pointer;

    display: flex;

    gap: 6px;

}

.if-inner-content {

    display: none;

    padding: 12px;

    margin-top: 6px;

    background: #f9fafc;

    border-radius: 8px;

}


/* ================= TEXT ================= */

.if-text {

    font-size: 14px;

    color: var(--muted);

    max-height: 60px;

    overflow: hidden;

}

.if-text.expanded {
    max-height: none;
}


/* ================= SEE MORE ================= */

.if-see-more {

    margin-top: 6px;

    border: none;

    background: none;

    color: var(--accent);

    font-weight: 600;

    cursor: pointer;

}


/* ================= ARROW ================= */

.if-arrow {

    font-size: 12px;

    transition: 0.25s;

}

.if-dropdown-btn.active .if-arrow,
.if-sub-btn.active .if-arrow,
.if-inner-btn.active .if-arrow {

    transform: rotate(180deg);

}


/* ================= DEBOUCHES ================= */

.if-inner-content ul {

    padding: 0;

    margin: 0;

    display: flex;

    flex-wrap: wrap;

    gap: 8px;

}

.if-inner-content li {

    list-style: none;

    background: white;

    padding: 6px 12px;

    border-radius: 20px;

    font-size: 13px;

    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);

}


/* ================= MOBILE ================= */

@media(max-width:576px) {

    .if-title {
        font-size: 18px;
    }

}
</style>


<body>

    <header class='header-section mb-0'>
        <div class='container mb-0'>

            <a href='<?= ROOT ?>/Homes' class='site-logo'>
                <img src='<?= ROOT ?>/assets/img/logo.png' alt='InfoFac' />
            </a>

            <div class='header-info'>

                <div class='hf-item'>
                    <i class='fa fa-graduation-cap'></i>
                    <p>
                        <span>Plateforme :</span>
                        Informations complètes pour les nouveaux bacheliers
                    </p>
                </div>

                <div class='hf-item'>
                    <i class='fa fa-map-marker'></i>
                    <p>
                        <span>Localisation :</span>
                        Bamako, Mali
                    </p>
                </div>

            </div>



        </div>
    </header>

    <section class="if-page">

        <a href="<?= ROOT ?>/Homes" class="if-back mb-2">← Retour</a>


        <section class="if-uni-header-premium">

            <!-- IMAGE COUVERTURE -->
            <div class="if-cover">

                <img src="<?= ROOT ?>/assets/img/logo.png"
                    class="if-cover-img" alt="<?= htmlspecialchars($universite->nom_universite) ?>">

                <div class="if-cover-overlay"></div>

            </div>


            <!-- LOGO + INFO -->
            <div class="if-uni-card">

                <div class="if-logo-wrapper">

                    <img src="<?= ROOT ?>/assets/img/logo.png"
                        class="if-logo-premium" alt="<?= htmlspecialchars($universite->nom_universite) ?>">

                </div>


                <div class="if-uni-info">

                    <h1 class="if-uni-name">
                        <?= htmlspecialchars($universite->nom_universite) ?>
                    </h1>

                    <?php
                    $type = strtolower($universite->type_universite) === 'publique' ? 'public' : 'prive';

                    $badgeStyle = strtolower($universite->type_universite) === 'publique'
                        ? "background:#e3f2fd;color:#1976d2;padding:6px 14px;border-radius:20px;font-size:13px;font-weight:600;"
                        : "background:#fff3e0;color:#ff9800;padding:6px 14px;border-radius:20px;font-size:13px;font-weight:600;";
                ?>

                    <span class="if-uni-badge <?= $type ?>" style="<?= $badgeStyle ?>">
                        Université <?= htmlspecialchars($universite->type_universite) ?>
                    </span>

                </div>

            </div>

        </section>


        <!-- DESCRIPTION -->
        <div class="if-dropdown">

            <button class="if-dropdown-btn">

                Description université

                <span class="if-arrow">▾</span>

            </button>

            <div class="if-dropdown-content">

                <p class="if-text">

                    <?= nl2br(htmlspecialchars($universite->description_universite)) ?>

                </p>

                <button class="if-see-more">
                    Voir plus
                    <span class="if-see-more-arrow">→</span>
                </button>

            </div>

        </div>


        <!-- DEBOUCHES (sera rempli dynamiquement plus tard avec les filières) -->
        <div class="if-inner-dropdown">

            <button class="if-dropdown-btn">

                Débouchés

                <span class="if-arrow">▾</span>

            </button>

            <div class="if-inner-content">

                <ul>

                    <li>Chargement des débouchés...</li>

                </ul>

            </div>

        </div>


    </section>

    <?php $this->view('Partials/footer') ?>

    <script>
    document.querySelectorAll(
        ".if-dropdown-btn, .if-sub-btn, .if-inner-btn"
    ).forEach(btn => {

        btn.onclick = () => {

            let content = btn.nextElementSibling;

            content.style.display =
                content.style.display === "block" ? "none" : "block";

            btn.classList.toggle("active");

        };

    });


    document.querySelectorAll(".if-see-more").forEach(btn => {

        btn.onclick = () => {

            let text = btn.previousElementSibling;

            text.classList.toggle("expanded");

            btn.innerText = text.classList.contains("expanded") ?
                "Voir moins" : "Voir plus";

        };

    });
    </script>

</body>

</html>