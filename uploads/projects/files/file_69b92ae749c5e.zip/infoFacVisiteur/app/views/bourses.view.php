
<!doctype html>
<html lang='fr'>

<!-- Debut head -->
<?php $this->view( 'Partials/header' ) ?>
<!-- Fin head -->

<body>
    <div id='preloder'>
        <div class='loader'></div>
    </div>

    <!-- ===  ===  ===  ===  ===  == HEADER TOP ===  ===  ===  ===  ===  == -->
    <!-- header section -->
    <header class='header-section mb-0'>
        <div class='container mb-0'>

            <a href='<?= ROOT ?>/Homes' class='site-logo'>
                <img src='<?= ROOT ?>/assets/img/logo.png' alt='InfoFac' />
            </a>

            <div class='header-info'>

                <div class='hf-item'>
                    <i class='fa fa-graduation-cap'></i>
                    <p>
                        <span>Plateforme :</span>
                        Informations complètes pour les nouveaux bacheliers
                    </p>
                </div>

                <div class='hf-item'>
                    <i class='fa fa-map-marker'></i>
                    <p>
                        <span>Localisation :</span>
                        Bamako, Mali
                    </p>
                </div>

            </div>

            <!-- MOBILE MENU BUTTON -->
            <div class='nav-switch'>
                <i class='fa fa-bars'></i>
            </div>

            <!-- HEADER INFORMATIONS -->

        </div>
    </header>
    <!-- ===  ===  ===  ===  ===  == END HEADER TOP ===  ===  ===  ===  ===  == -->

    <!-- ===  ===  ===  ===  ===  == NAVIGATION ===  ===  ===  ===  ===  == -->
    <nav class='nav-section'>

        <div class='container nav-container'>

            <!-- RIGHT ICONS -->
            <div class='nav-right'>

                <!-- SEARCH BUTTON -->
                <a href='<?= ROOT ?>/Recherche' class='nav-icon' title='Rechercher une filière'>
                    <i class='fa fa-search'></i>
                </a>

                <!-- USER SPACE -->
                <a href='<?= ROOT ?>/Compte' class='nav-icon' title='Mon compte'>
                    <i class='fa fa-user'></i>
                </a>

            </div>

            <!-- MAIN MENU -->
            <ul class='main-menu' id='mainMenu'>

                <li class=''>
                    <a href='<?= ROOT ?>/Homes'>
                        <i class='fa fa-home'></i> Accueil
                    </a>
                </li>
                <li class=''>
                    <a href='<?= ROOT ?>/Homes#universites'>
                        <i class='fa fa-university'></i> Universites
                    </a>
                </li>

                <li class='active'>
                    <a href='#'>
                        <i class='fa fa-money'></i> Bourses
                    </a>
                </li>

                <li>
                    <a href='#conseils'>
                        <i class='fa fa-lightbulb-o'></i> Conseils
                    </a>
                </li>

            </ul>

        </div>

    </nav>

    <hr>
    <!-- les bourses -->
 <section class='if-bourse-section' id='bourses'>

    <h3 class='if-universite-title mb-2'>
        Bourses Disponibles
    </h3>

    <?php if(!empty($bourses)): ?>

        <?php foreach($bourses as $bourse): ?>

        <div class='if-bourse-card'>

            <!-- PARTIE GAUCHE -->
            <div class='if-bourse-info'>

                <div class='if-bourse-header'>

                    <div class='if-bourse-icon'>
                        <i class='fa fa-money'></i>
                    </div>

                    <div>

                        <h2 class='if-bourse-title'>
                            <?= htmlspecialchars($bourse->nom_bourse) ?>
                        </h2>

                        <div class='if-bourse-level'>
                            <?= htmlspecialchars($bourse->niveau) ?>
                        </div>

                    </div>

                </div>

                <div class='if-bourse-meta'>

                    <div class='if-meta-item'>
                        <i class='fa fa-university'></i>
                        <?= htmlspecialchars($bourse->organisme_bourse) ?>
                    </div>

                    <div class='if-meta-item'>
                        <i class='fa fa-calendar'></i>
                        Date limite : 
                        <?= date('d F Y', strtotime($bourse->date_fin)) ?>
                    </div>

                </div>

                <p class='if-bourse-desc'>
                    <?= htmlspecialchars($bourse->description_bourse) ?>
                </p>

            </div>

            <!-- PARTIE DROITE (COMPTEUR) -->
            <div class='if-counter' 
                 data-date="<?= $bourse->date_fin ?>">

                <div class='if-counter-box'>
                    <div class='if-counter-number days'>00</div>
                    <div class='if-counter-text'>Jours</div>
                </div>

                <div class='if-counter-box'>
                    <div class='if-counter-number hours'>00</div>
                    <div class='if-counter-text'>Heures</div>
                </div>

                <div class='if-counter-box'>
                    <div class='if-counter-number minutes'>00</div>
                    <div class='if-counter-text'>Minutes</div>
                </div>

                <div class='if-counter-box'>
                    <div class='if-counter-number seconds'>00</div>
                    <div class='if-counter-text'>Secondes</div>
                </div>

            </div>

        </div>

        <?php endforeach ?>

    <?php else: ?>

        <p>Aucune bourse disponible actuellement.</p>

    <?php endif ?>

</section>

    <!-- Footer section -->
    <?php $this->view( 'Partials/foot' ) ?>
    <!-- Footer section end-->

    <!-- ===  === Javascripts & Jquery ===  === -->
    <?php $this->view( 'Partials/footer' ) ?>

    <script>
    const filterButtons = document.querySelectorAll(".if-filter-btn");
    const cards = document.querySelectorAll(".if-universite-card");

    filterButtons.forEach(button => {

        button.addEventListener("click", () => {

            filterButtons.forEach(btn => btn.classList.remove("active"));

            button.classList.add("active");

            const filter = button.dataset.filter;

            cards.forEach(card => {

                const type = card.dataset.type;

                if (filter === "all" || type === filter) {

                    card.parentElement.style.display = "block";

                } else {

                    card.parentElement.style.display = "none";

                }

            });

        });

    });
    </script>
</body>

</html>