<?php
$sliders = [

    [
        'image' => 'usttb.jpg',
        'subtitle' => 'Université des Sciences, Techniques et Technologies de Bamako',
        'title' => 'Appuie science & technologie au Mali',
        'description' => "L’USTTB est l'une des universités publiques les plus reconnues du Mali pour l’enseignement scientifique et technique.",
        'button_text' => 'Voir filières Science',
        'button_link' => ROOT.'/Filieres?uni=usttb'
    ],

    [
        'image' => 'ulshb.jpg',
        'subtitle' => 'Université des Lettres et Sciences Humaines de Bamako',
        'title' => 'Arts, Langues et Relations Humaines',
        'description' => 'ULSHB propose des formations en lettres, sciences humaines et communication pour guider ton avenir.',
        'button_text' => 'Découvrir Humanités',
        'button_link' => ROOT.'/Filieres?uni=ulshb'
    ],

    [
        'image' => 'ussgb.jpg',
        'subtitle' => 'Université des Sciences Sociales et de Gestion de Bamako',
        'title' => 'Economies, Gestion & Sciences sociales',
        'description' => 'USSGB offre des cours en économie, gestion d’entreprise et sciences sociales pour les futurs leaders.',
        'button_text' => 'Explorer Management',
        'button_link' => ROOT.'/Filieres?uni=ussgb'
    ],

    [
        'image' => 'usjpb.jpg',
        'subtitle' => 'Université des Sciences Juridiques et Politiques de Bamako',
        'title' => 'Droit, Administration & Gouvernance',
        'description' => 'USJPB est spécialisée dans les domaines du droit, sciences politiques et administration publique.',
        'button_text' => 'Voir filières Droit',
        'button_link' => ROOT.'/Filieres?uni=usjpb'
    ],

    [
        'image' => 'segou.jpg',
        'subtitle' => 'Université de Ségou',
        'title' => 'Formation Académique à Ségou',
        'description' => "L'Université de Ségou propose des formations variées comme agronomie, sciences sociales et techniques.",
        'button_text' => 'Découvrir Ségou',
        'button_link' => ROOT.'/Filieres?uni=segou'
    ]

];
?>

<!doctype html>
<html lang='fr'>

<!-- Debut head -->
<?php $this->view( 'Partials/header' ) ?>
<!-- Fin head -->

<body>
    <div id='preloder'>
        <div class='loader'></div>
    </div>

    <!-- ===  ===  ===  ===  ===  == HEADER TOP ===  ===  ===  ===  ===  == -->
    <!-- header section -->
    <header class='header-section mb-0'>
        <div class='container mb-0'>

            <a href='<?= ROOT ?>/Homes' class='site-logo'>
                <img src='<?= ROOT ?>/assets/img/logo.png' alt='InfoFac' />
            </a>

            <div class='header-info'>

                <div class='hf-item'>
                    <i class='fa fa-graduation-cap'></i>
                    <p>
                        <span>Plateforme :</span>
                        Informations complètes pour les nouveaux bacheliers
                    </p>
                </div>

                <div class='hf-item'>
                    <i class='fa fa-map-marker'></i>
                    <p>
                        <span>Localisation :</span>
                        Bamako, Mali
                    </p>
                </div>

            </div>

            <!-- MOBILE MENU BUTTON -->
            <div class='nav-switch'>
                <i class='fa fa-bars'></i>
            </div>

            <!-- HEADER INFORMATIONS -->

        </div>
    </header>
    <!-- ===  ===  ===  ===  ===  == END HEADER TOP ===  ===  ===  ===  ===  == -->

    <!-- ===  ===  ===  ===  ===  == NAVIGATION ===  ===  ===  ===  ===  == -->
    <nav class='nav-section'>

        <div class='container nav-container'>

            <!-- RIGHT ICONS -->
            <div class='nav-right'>

                <!-- SEARCH BUTTON -->
                <a href='<?= ROOT ?>/Recherche' class='nav-icon' title='Rechercher une filière'>
                    <i class='fa fa-search'></i>
                </a>

                <!-- USER SPACE -->
                <a href='<?= ROOT ?>/Compte' class='nav-icon' title='Mon compte'>
                    <i class='fa fa-user'></i>
                </a>

            </div>

            <!-- MAIN MENU -->
            <ul class='main-menu' id='mainMenu'>

                <li class='active'>
                    <a href='#'>
                        <i class='fa fa-home'></i> Accueil
                    </a>
                </li>
                <li class=''>
                    <a href='#universites'>
                        <i class='fa fa-university'></i> Universites
                    </a>
                </li>

                <li>
                    <a href='<?= ROOT ?>/Bourses'>
                        <i class='fa fa-money'></i> Bourses
                    </a>
                </li>

                <li>
                    <a href='#conseils'>
                        <i class='fa fa-lightbulb-o'></i> Conseils
                    </a>
                </li>

            </ul>

        </div>

    </nav>
    <!-- ===  ===  ===  ===  ===  == END NAVIGATION ===  ===  ===  ===  ===  == -->
    <div class='serie-container'>

        <label for='serie' class='serie-label'>
            Choisissez votre série du Bac
        </label>

        <div class='serie-select-wrapper'>

            <i class='fa fa-graduation-cap serie-icon'></i>

            <select id='serie' name='serie' class='serie-select'>

                <option value=''>-- Sélectionner votre série --</option>

                <option value='TSE'>TSE - Sciences Exactes</option>

                <option value='TSS'>TSS - Sciences Sociales</option>

                <option value='TLL'>TLL - Lettres et Langues</option>

                <option value='TSECO'>TSECO - Sciences Economiques</option>

                <option value='TSExp'>TSExp - Sciences Expérimentales</option>

            </select>

        </div>

    </div>

    <!-- Hero section -->
    <section class='hero-section '>
        <div class='hero-slider owl-carousel '>

            <?php foreach ( $sliders as $slider ): ?>

            <div class='hs-item set-bg'
                data-setbg="<?= ROOT ?>/assets/img/universite/<?= htmlspecialchars($slider['image']) ?>">

                <div class='hs-overlay'></div>

                <div class='hs-text'>
                    <div class='container'>
                        <div class='row'>
                            <div class='col-lg-8 col-md-10'>

                                <div class='hs-subtitle'>
                                    <?php echo htmlspecialchars( $slider[ 'subtitle' ] ) ?>
                                </div>

                                <h2 class='hs-title'>
                                    <?php echo htmlspecialchars( $slider[ 'title' ] ) ?>
                                </h2>

                                <p class='hs-des'>
                                    <?php echo htmlspecialchars( $slider[ 'description' ] ) ?>
                                </p>

                                <?php if ( !empty( $slider[ 'button_text' ] ) ): ?>
                                <a href="<?= $slider['button_link'] ?>" class='site-btn'>
                                    <?php echo htmlspecialchars( $slider[ 'button_text' ] ) ?>
                                </a>
                                <?php endif?>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <?php endforeach?>

        </div>
    </section>
    <!-- Hero section end -->

    <!-- les universties -->
    <section class='if-universite-section' id='universites'>

        <!-- HEADER -->
        <div class='if-universite-header'>

            <h2 class='if-universite-title'>
                Facultés Disponibles
            </h2>

            <!-- FILTRE -->
            <div class='if-filter'>

                <button class='if-filter-btn active' data-filter='all'>
                    Toutes
                </button>

                <button class='if-filter-btn' data-filter='Publique'>
                    Public
                </button>

                <button class='if-filter-btn' data-filter='Privée'>
                    Privé
                </button>

            </div>

        </div>

        <!-- LISTE UNIVERSITES -->
        <div class='if-universite-grid' id='universiteGrid'>

            <?php if ( !empty( $universites ) ): ?>

            <?php foreach ( $universites as $uni ): ?>

            <?php $type = strtolower( $uni->type_universite );
                $logo = !empty( $uni->logo_universite )? ROOT.'/assets/img/logo.jpg' : ROOT.'/uploads/'.$uni->logo_universite;
            ?>

            <a href="<?= ROOT ?>/Universites/details/<?= $uni->id_universite ?>" class='if-universite-link'>

                <div class='if-universite-card' data-type="<?= $uni->type_universite ?>">

                    <img src="<?= $logo ?>" class='if-universite-img'
                        alt="<?= htmlspecialchars($uni->nom_universite) ?>">

                    <div class='if-universite-body'>

                        <h4 class="text-uppercase" style="
                            font-size: 15px;
                            font-weight: 700;
                            color: #02023d;
                            margin-bottom: 5px;
                            line-height: 1.3;
                            letter-spacing: 0.4px;
                            display: flex;
                            flex-wrap: wrap;
                            align-items: center;
                            gap: 6px;
                        ">

                            <?php echo htmlspecialchars($uni->nom_universite) ?>

                            <span style="
                                font-size: 12px;
                                font-weight: 500;
                                color: #6c757d;
                                background: #f1f3f7;
                                padding: 2px 8px;
                                border-radius: 20px;
                                text-transform: capitalize;
                                letter-spacing: 0.3px;
                            ">
                                <?php echo htmlspecialchars($uni->ville_universite) ?>
                            </span>

                        </h4>

                        <?php
                            $type = htmlspecialchars($uni->type_universite);

                            $badgeStyle = $type === "Publique"
                                ? "background:linear-gradient(135deg,#e3f2fd,#bbdefb);
                                color:#1976d2;
                                border:1px solid #90caf9;
                                    display:inline-block;
                                    padding:4px 12px;
                                    border-radius:20px;
                                    font-size:11px;
                                    font-weight:600;
                                    letter-spacing:.3px;"
                                : "background:linear-gradient(135deg,#fff3e0,#ffe0b2);
                                color:#f57c00;
                                border:1px solid #ffcc80;
                                    display:inline-block;
                                    padding:4px 12px;
                                    border-radius:20px;
                                    font-size:11px;
                                    font-weight:600;
                                    letter-spacing:.3px;"
                                ;
                        ?>

                        <span class="if-badge" style="<?= $badgeStyle ?>">
                            <?= $type ?>
                        </span>

                        <p style="
                            margin:0;
                            margin-top:6px;
                            font-size:13px;
                            line-height:1.5;
                            color:#6c757d;
                            display:-webkit-box;
                            -webkit-line-clamp:2;
                            -webkit-box-orient:vertical;
                            overflow:hidden;
                            text-overflow:ellipsis;
                        ">
                            <?php
                                echo !empty($uni->description_universite)
                                ? htmlspecialchars($uni->description_universite)
                                : "Aucune description disponible pour cette université.";
                            ?>
                        </p>

                    </div>

                </div>

            </a>

            <?php endforeach;?>

            <?php else: ?>

            <p>Aucune université disponible.</p>

            <?php endif;?>

        </div>

    </section>

    <hr>
    <!-- les bourses -->
    <section class='if-bourse-section' id='bourses'>
        <h3 class='if-universite-title mb-2'>
            Bourses Disponibles
        </h3>
        <div class='if-bourse-card'>

            <!-- PARTIE GAUCHE -->
            <div class='if-bourse-info'>

                <div class='if-bourse-header'>

                    <div class='if-bourse-icon'>
                        <i class='fa fa-money'></i>
                    </div>

                    <div>
                        <h2 class='if-bourse-title'>
                            Bourse Nationale du Mali 2026
                        </h2>

                        <div class='if-bourse-level'>
                            Licence 1
                        </div>
                    </div>

                </div>

                <div class='if-bourse-meta'>

                    <div class='if-meta-item'>
                        <i class='fa fa-university'></i>
                        Ministère de l’Enseignement Supérieur
                    </div>

                    <div class='if-meta-item'>
                        <i class='fa fa-calendar'></i>
                        Date limite : 30 Septembre 2026
                    </div>

                </div>

                <p class='if-bourse-desc'>

                    Cette bourse est destinée aux nouveaux bacheliers maliens souhaitant
                    poursuivre leurs études dans les universités publiques du Mali.

                </p>

            </div>

            <!-- PARTIE DROITE ( COMPTEUR ) -->
            <div class='if-counter'>

                <div class='if-counter-box'>
                    <div class='if-counter-number'>20</div>
                    <div class='if-counter-text'>Jours</div>
                </div>

                <div class='if-counter-box'>
                    <div class='if-counter-number'>08</div>
                    <div class='if-counter-text'>Heures</div>
                </div>

                <div class='if-counter-box'>
                    <div class='if-counter-number'>40</div>
                    <div class='if-counter-text'>Minutes</div>
                </div>

                <div class='if-counter-box'>
                    <div class='if-counter-number'>56</div>
                    <div class='if-counter-text'>Secondes</div>
                </div>

            </div>

        </div>

    </section>

    <!-- Footer section -->
    <?php $this->view( 'Partials/foot' ) ?>
    <!-- Footer section end-->

    <!-- ===  === Javascripts & Jquery ===  === -->
    <?php $this->view( 'Partials/footer' ) ?>

    <script>
    const filterButtons = document.querySelectorAll(".if-filter-btn");
    const cards = document.querySelectorAll(".if-universite-card");

    filterButtons.forEach(button => {

        button.addEventListener("click", () => {

            filterButtons.forEach(btn => btn.classList.remove("active"));

            button.classList.add("active");

            const filter = button.dataset.filter;

            cards.forEach(card => {

                const type = card.dataset.type;

                if (filter === "all" || type === filter) {

                    card.parentElement.style.display = "block";

                } else {

                    card.parentElement.style.display = "none";

                }

            });

        });

    });
    </script>
</body>

</html>