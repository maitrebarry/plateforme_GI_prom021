<?php
define( 'ROOT', 'http://localhost/infoFacVisiteur/public' );
define( 'ROOT_PUBLIC', $_SERVER[ 'DOCUMENT_ROOT' ] . '/infoFacVisiteur/public' );

define( 'DB_NAME', 'orientation_universitaire_etudiants' );
define( 'DBHOST', 'localhost' );
define( 'DB_USERNAME', 'root' );
define( 'DB_PASSWORD', '' );
define( 'DBDRIVER', 'mysql' );